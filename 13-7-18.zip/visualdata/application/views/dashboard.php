<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        <i class="fa fa-tachometer" aria-hidden="true"></i> Dashboard
        <small>Control panel</small>
      </h1>
    </section>
	<section class="content">
	</section>
	<div class="container-fluid">
		<div id="container2a" class="col-xs-12 col-sm-12 col-md-6 col-lg-6" onclick="window.location='<?php echo site_url('Pieonclick'); ?>';" style="min-width: 310px; height: auto; margin: 0 auto;cursor: pointer;"></div>
		<div id="container2b" class="col-xs-12 col-sm-12 col-md-6 col-lg-6" onclick="window.location='<?php echo site_url('Pieonclick/mc'); ?>';" style="min-width: 310px; height: auto; margin: 0 auto;cursor: pointer;"></div>
	</div>
</div>

<script type="text/javascript">
$(document).ready(function () {
Highcharts.chart('container2a', {
    chart: {
        type: 'pie',
        options3d: {
            enabled: true,
            alpha: 45
        }
    },
    title: {
        text: 'Supplier Performance',
		style: {
			 color: '#3c8dbc'
		  }
    },
    subtitle: {
        text: '<?php echo $display_pie['correction_dc'];  ?>',
		style: {
			 color: '#3c8dbc'
		  }			
    },
    plotOptions: {
		pie: {
            innerSize: 100,
            depth: 45,
			allowPointSelect: true,
            cursor: 'pointer',
            dataLabels: {
                enabled: true,
                format: '{point.percentage:.1f} %',
                style: {
                    color: (Highcharts.theme && Highcharts.theme.contrastTextColor) || 'black'
                }
            },
            showInLegend: true
        }
    },
    series: [{
        name: '<?php echo $display_pie['correction_dc'];  ?>',
        data: [
            ['<?php echo $display_pie['car_suppliers_dc_0']; ?>', <?php echo $display_pie['dpr_dc_0']; ?>],
            ['<?php echo $display_pie['car_suppliers_dc_1']; ?>', <?php echo $display_pie['dpr_dc_1']; ?>],
            ['<?php echo $display_pie['car_suppliers_dc_2']; ?>', <?php echo $display_pie['dpr_dc_2']; ?>],
            ['<?php echo $display_pie['car_suppliers_dc_3']; ?>', <?php echo $display_pie['dpr_dc_3']; ?>]
        ]
    }],
	colors: ['#7cb5ec', '#f15c80','#90ed7d', '#f7a35c']
});

Highcharts.chart('container2b', {
    chart: {
        type: 'pie',
        options3d: {
            enabled: true,
            alpha: 45
        }
    },
    title: {
        text: 'Supplier Performance',
		style: {
			 color: '#3c8dbc'
		  }
    },
    subtitle: {
        text: '<?php echo $display_pie['correction_mc']; ?>',
		style: {
			 color: '#3c8dbc'
		  }			
    },
    plotOptions: {
		pie: {
            innerSize: 100,
            depth: 45,
			allowPointSelect: true,
            cursor: 'pointer',
            dataLabels: {
                enabled: true,
                format: '{point.percentage:.1f} %',
                style: {
                    color: (Highcharts.theme && Highcharts.theme.contrastTextColor) || 'black'
                }
            },
            showInLegend: true
        }
    },
    series: [{
        name: '<?php echo $display_pie['correction_mc'];  ?>',
        data: [
            ['<?php echo $display_pie['car_suppliers_mc_0']; ?>', <?php echo $display_pie['dpr_mc_0']; ?>],
            ['<?php echo $display_pie['car_suppliers_mc_1']; ?>', <?php echo $display_pie['dpr_mc_1']; ?>],
            ['<?php echo $display_pie['car_suppliers_mc_2']; ?>', <?php echo $display_pie['dpr_mc_2']; ?>],
            ['<?php echo $display_pie['car_suppliers_mc_3']; ?>', <?php echo $display_pie['dpr_mc_3']; ?>]
        ]
    }],
	colors: ['#7cb5ec', '#f15c80','#90ed7d', '#f7a35c']
});
});
</script>