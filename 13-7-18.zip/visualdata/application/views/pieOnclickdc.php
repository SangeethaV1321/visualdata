<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        <i class="fa fa-tachometer" aria-hidden="true"></i> Dashboard
        <small>Control panel</small>
      </h1>
    </section>
    
<section class="content">
    <div class="row">
	</div>
<div class="row">
<div class="container-fluid">
<form method="post" id="week_submit" action="<?php echo base_url('pieOnclick') ?>">
	<!-- <h3 class="title1">Corrections :</h3> -->
    <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
		<div class="item item-input">
			<span class="input-label week_range">Week Range :</span>
			
			<label class="custom-select">
			<select name="from_week" id="period">
				<option value="1">From week</option>			
				<?php for ($i = 1; $i < 53; $i++) { ?>
					<option value="<?php echo $i; ?>" <?php if ($period == $i) echo 'selected="selected"'; ?> ><?php echo $i; ?></option>	
				<?php } ?>	
			</select>
			</label>
			
			<label class="custom-select">
			<select name="to_week" id="periode">
				<option value="">To week</option>
				<?php  if(!isset($_POST["to_week"])){ ?>
				<?php      
				$date = new DateTime();
				echo $week = $date->format("W");
				?>
				<option value="<?php echo $week; ?>" <?php echo 'selected="selected"'; ?> ><?php echo $week; ?></option>
				<?php } else{ ?>
				<?php for ($i = 1; $i < 53; $i++) { ?>
					<option value="<?php echo $i; ?>" <?php if ($periode == $i) echo 'selected="selected"'; ?> ><?php echo $i; ?></option>
				<?php }  }   ?>
			</select>
			</label>
			
		</div>
	</div>
</form>
</div>
</div>
</section>
<?php
$date = new DateTime();
$week = $date->format("W");
if (!empty($period)) {
    $from_week = $period;
} else {
    $from_week = '1';
} 
if (!empty($periode)) {
    $to_week = $periode;
} else {
    $to_week = $week;
}

$text = 'Week';
foreach (range($from_week, $to_week) as $letter) {
    $res[] = $text . $letter;
}
$week_value = "'" . implode("','", $res) . "'";

  $minimum_dc = $car_supplier['minVal_dc']; 
  $maximum_dc = $car_supplier['maxVal_dc']; 
	if($maximum_dc >= $minimum_dc) {
	$interval_dc = round($maximum_dc/2);
	} else {
	$interval_dc = round($minimum_dc/2);
	}

?>
<a id="back" href="<?php echo site_url('dashboard'); ?>"><span id="backtodb"><i class="fa fa-arrow-left"></i> Back</span></a>
<div id="container1a" style="min-width: 310px; height: auto; margin: 0 auto; margin-bottom:15px; margin-top:15px;"></div>
<div id="container3" style="min-width: 310px; height: auto; margin: 0 auto; margin-bottom:15px;"></div>

</div>



<?php
    if ( ! isset($_POST['to_week']) ) { // not submitted yet
?>
<script>
$(document).ready(function(){
	$("#week_submit").submit();
});  
</script>
<?php
    }
?>
<script type="text/javascript">
$(document).ready(function(){
$("#periode").change(function () {
	var from_select = Number($( "#period option:selected" ).text());
	var to_select = Number($( "#periode option:selected" ).text());
	if ((from_select) < (to_select)) {
		$("#week_submit").submit();
	} else {		
		alert('To week should be greater than From week!');
	}
}); 
$("#period").change(function () {
	var from_select = Number($( "#period option:selected" ).text());
	var to_select = Number($( "#periode option:selected" ).text());
	if ((from_select) < (to_select)) {
		$("#week_submit").submit();
	} else {		
		alert('From week should be lesser than To week!');
	}
});
/* $("#correction_type").change(function () {
	$("#week_submit").submit();
}); */ 
});
</script>

<script type="text/javascript">
$(document).ready(function () {
Highcharts.chart('container1a', {
	xAxis: {
		categories: [<?php echo $week_value;?>],
		tickInterval: '1',
		max: '<?php echo $week;?>',
		title: {
			text: 'Week Number'
		}
	},
	yAxis: {
		min: <?php echo $minimum_dc;?>,
		max: <?php echo $maximum_dc;?>,
		tickInterval: <?php echo $interval_dc;?>,
		title: {
			text: 'No. of DPRs'
		}
	},
	tooltip: {
		backgroundColor: '#000000',
		borderColor: '#000000',
		borderRadius: 10,
		borderWidth: 3,
		style:{color : '#fff'}
	},
	plotOptions: {
		spline: {
			lineWidth: 2,
			states: {
				hover: {
					lineWidth: 3
				}
			}
		}
	},
	title: {
		text: 'Data Correction',
		style: {
			 color: '#3c8dbc'
		  }
	},
	subtitle: {
        text: 'Weekly',
		style: {
			 color: '#3c8dbc'
		  }			
    },
	series: [{
		type: 'spline',
		name: '<?php echo $displaysupply['supplier_0']; ?>',
		data: [<?php echo $displaysupply['tdtot_dc_0'];?>]
	}, {
		type: 'spline',
		name: '<?php echo $displaysupply['supplier_1']; ?>',
		data: [<?php echo $displaysupply['tdtot_dc_1'];?>]
	}, {
		type: 'spline',
		name: '<?php echo $displaysupply['supplier_2']; ?>',
		data: [<?php echo $displaysupply['tdtot_dc_2'];?>]
	}, {
		type: 'spline',
		name: '<?php echo $displaysupply['supplier_3']; ?>',
		data: [<?php echo $displaysupply['tdtot_dc_3'];?>]
	}],
	colors: ['#7cb5ec', '#f15c80','#90ed7d', '#f7a35c']
});

Highcharts.chart('container3', {
    chart: {
        type: 'column'
    },
    title: {
        text: 'Data Corrections',
		style: {
			 color: '#3c8dbc'
		  }
    },
	subtitle: {
        text: 'Correction Field',
		style: {
			 color: '#3c8dbc'
		  }			
    },
    xAxis: {
        categories: [<?php echo $display_bar_supplier['corrections']; ?>],
        crosshair: true,
		title: {
            text: 'Correction Field'
        }
    },
    yAxis: {
        min: 0,
        title: {
            text: 'No. of DPRs'
        },
        stackLabels: {
            enabled: true,
            style: {
                fontWeight: 'bold',
                color: (Highcharts.theme && Highcharts.theme.textColor) || 'gray'
            }
        }
    },
    /* legend: {
        align: 'right',
        x: -30,
        verticalAlign: 'top',
        y: 25,
        floating: true,
        backgroundColor: (Highcharts.theme && Highcharts.theme.background2) || 'white',
        borderColor: '#CCC',
        borderWidth: 1,
        shadow: false
    }, */
    /* tooltip: {
        headerFormat: '<b>{point.x}</b><br/>',
        pointFormat: '{series.name}: {point.y}<br/>Total: {point.stackTotal}'
    }, */
	tooltip: {
        headerFormat: '<span style="font-size:10px">{point.key}</span><table>',
        pointFormat: '<tr><td style="color:{series.color};padding:0">{series.name}: </td>' +
            '<td style="padding:0"><b>{point.y}</b></td></tr>',
        footerFormat: '</table>',
        shared: true,
        useHTML: true,
		backgroundColor: '#000000',
		borderColor: '#000000',
		borderRadius: 10,
		borderWidth: 3,
		style:{color : '#fff'}
    },
    plotOptions: {
        column: {
            stacking: 'normal'/* ,
            dataLabels: {
                enabled: true,
                color: (Highcharts.theme && Highcharts.theme.dataLabelsColor) || 'white'
            } 
			/* ,
            dataLabels: {
                enabled: true,
                formatter: function(){
                    console.log(this);
                    var val = this.y;
                    if (val > 30) {
                        return '';
                    }
                    return val;
                },
                color: (Highcharts.theme && Highcharts.theme.dataLabelsColor) || 'white'
            },
            treshold: 1 */
        }
    },
    series: [{
        name: '<?php echo $display_bar_supplier['supplier_0']; ?>',
        data: [<?php echo $display_bar_supplier['tdtot_0'];?>]
    }, {
        name: '<?php echo $display_bar_supplier['supplier_1']; ?>',
        data: [<?php echo $display_bar_supplier['tdtot_1'];?>]

    }, {
        name: '<?php echo $display_bar_supplier['supplier_2']; ?>',
        data: [<?php echo $display_bar_supplier['tdtot_2'];?>]

    }, {
        name: '<?php echo $display_bar_supplier['supplier_3']; ?>',
        data: [<?php echo $display_bar_supplier['tdtot_3'];?>]

    }],
	colors: ['#7cb5ec', '#f15c80','#90ed7d', '#f7a35c']
});
});
</script>