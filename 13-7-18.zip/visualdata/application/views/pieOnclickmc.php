<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        <i class="fa fa-tachometer" aria-hidden="true"></i> Dashboard
        <small>Control panel</small>
      </h1>
    </section>
    
<section class="content">
    <div class="row">
	</div>
<div class="row">
<div class="container-fluid">
<form method="post" id="week_submit" action="<?php echo base_url('pieOnclick/mc') ?>">
	<!-- <h3 class="title1">Corrections :</h3> -->
    <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
		<div class="item item-input">
			<span class="input-label week_range">Week Range :</span>
			
			<label class="custom-select">
			<select name="from_week" id="period">
				<option value="1">From week</option>			
				<?php for ($i = 1; $i < 53; $i++) { ?>
					<option value="<?php echo $i; ?>" <?php if ($period == $i) echo 'selected="selected"'; ?> ><?php echo $i; ?></option>	
				<?php } ?>	
			</select>
			</label>
			
			<label class="custom-select">
			<select name="to_week" id="periode">
				<option value="">To week</option>
				<?php  if(!isset($_POST["to_week"])){ ?>
				<?php      
				$date = new DateTime();
				echo $week = $date->format("W");
				?>
				<option value="<?php echo $week; ?>" <?php echo 'selected="selected"'; ?> ><?php echo $week; ?></option>
				<?php } else{ ?>
				<?php for ($i = 1; $i < 53; $i++) { ?>
					<option value="<?php echo $i; ?>" <?php if ($periode == $i) echo 'selected="selected"'; ?> ><?php echo $i; ?></option>
				<?php }  }   ?>
			</select>
			</label>
			
		</div>
	</div>
</form>
</div>
</div>
</section>
<?php
$date = new DateTime();
$week = $date->format("W");
if (!empty($period)) {
    $from_week = $period;
} else {
    $from_week = '1';
} 
if (!empty($periode)) {
    $to_week = $periode;
} else {
    $to_week = $week;
}
$text = 'Week';
foreach (range($from_week, $to_week) as $letter) {
    $res[] = $text . $letter;
}
$week_value = "'" . implode("','", $res) . "'";

 $minimum_mc = $car_supplier['minVal_mc'];
 $maximum_mc = $car_supplier['maxVal_mc'];
	if($maximum_mc >= $minimum_mc) {
	$interval_mc = round($maximum_mc/2);
	} else {
	$interval_mc = round($minimum_mc/2);
	}	

?>
<a id="back" href="<?php echo site_url('dashboard'); ?>"><span id="backtodb"><i class="fa fa-arrow-left"></i> Back</span></a>
<div id="container1b" style="min-width: 310px; height: auto; margin: 0 auto; margin-bottom:15px; margin-top:15px;"></div>
</div>



<?php
    if ( ! isset($_POST['to_week']) ) { // not submitted yet
?>
<script>
$(document).ready(function(){
	$("#week_submit").submit();
});  
</script>
<?php
    }
?>
<script type="text/javascript">
$(document).ready(function(){
$("#periode").change(function () {
	var from_select = Number($( "#period option:selected" ).text());
	var to_select = Number($( "#periode option:selected" ).text());
	if ((from_select) < (to_select)) {
		$("#week_submit").submit();
	} else {		
		alert('To week should be greater than From week!');
	}
}); 
$("#period").change(function () {
	var from_select = Number($( "#period option:selected" ).text());
	var to_select = Number($( "#periode option:selected" ).text());
	if ((from_select) < (to_select)) {
		$("#week_submit").submit();
	} else {		
		alert('From week should be lesser than To week!');
	}
});
});
</script>

<script type="text/javascript">
$(document).ready(function () {
Highcharts.chart('container1b', {
	xAxis: {
		categories: [<?php echo $week_value;?>],
		tickInterval: '1',
		max: '<?php echo $week;?>',
		title: {
			text: 'Week Number'
		}
	},
	yAxis: {
		min: <?php echo $minimum_mc;?>,
		max: <?php echo $maximum_mc;?>,
		tickInterval: <?php echo $interval_mc;?>,
		title: {
			text: 'No. of DPRs'
		}
	},
	tooltip: {
		backgroundColor: '#000000',
		borderColor: '#000000',
		borderRadius: 10,
		borderWidth: 3,
		style:{color : '#fff'}
	},
	plotOptions: {
		spline: {
			lineWidth: 2,
			states: {
				hover: {
					lineWidth: 3
				}
			}
		}
	},
	title: {
		text: 'Missing Content',
		style: {
			 color: '#3c8dbc'
		  }
	},
	subtitle: {
        text: 'Weekly',
		style: {
			 color: '#3c8dbc'
		  }			
    },
	series: [{
		type: 'spline',
		name: '<?php echo $displaysupply['supplier_0']; ?>',
		data: [<?php echo $displaysupply['tdtot_mc_0'];?>]
	}, {
		type: 'spline',
		name: '<?php echo $displaysupply['supplier_1']; ?>',
		data: [<?php echo $displaysupply['tdtot_mc_1'];?>]
	}, {
		type: 'spline',
		name: '<?php echo $displaysupply['supplier_2']; ?>',
		data: [<?php echo $displaysupply['tdtot_mc_2'];?>]
	}, {
		type: 'spline',
		name: '<?php echo $displaysupply['supplier_3']; ?>',
		data: [<?php echo $displaysupply['tdtot_mc_3'];?>]
	}],
	colors: ['#7cb5ec', '#f15c80','#90ed7d', '#f7a35c']
});
});
</script>