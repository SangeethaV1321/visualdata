<?php if(!defined('BASEPATH')) exit('No direct script access allowed');
require APPPATH . '/libraries/BaseController.php';

class Uploadfile extends BaseController {
public function __construct()
{
    parent::__construct();
    //$this->load->helper('url');                    
    $this->load->model('Uploadfile_model');
	$this->isLoggedIn();  
}

public function index()
{   
	$this->global['pageTitle'] = 'Data Visualization - CSV Upload';
	$this->loadViews("uploadfile", $this->global, NULL , NULL);
}

	////////////////// Import subscriber emails ////////////////////////////////
/* public function importbulkemail(){
	$this->loadViews('upload');
} */

    public function import()
    {
        set_time_limit(0);
        error_reporting(E_ALL);
        try {
            if (isset($_POST["import"])) {
                $filename = $_FILES["file"]["tmp_name"];
                if ($_FILES["file"]["size"] > 0) {
                    $file = fopen($filename, "r");
                    $i = 0;
					$current_date = date("Y-m-d");
                    //while (($importdata = fgetcsv($file, 10000, ",")) !== FALSE) {
					$header = fgetcsv($file);
                    while (($importdata = fgetcsv($file)) !== FALSE) {
					
					 $record = array_combine($header, $importdata);
					 /* print_r($record);
					 echo $record["Source ID "];
					 exit; */
					 
					   
                        if($i > 0) {
						$myDateTime = DateTime::createFromFormat('j-M-Y', $record["Report Date"]);
						$formattedweekdate =  $myDateTime->format('y-m-d');
						
						$duedt = explode("-", $formattedweekdate);
						$date  = mktime(0, 0, 0, $duedt[1], $duedt[2], $duedt[0]);
						$weekmum  = (int)date('W', $date);
						$daysofweek = (int)date('w', $date);
						if($daysofweek == 0 || $daysofweek == 6){
							$week  = $weekmum+1;
						}
						else{
							$week  = $weekmum;
						}
						//$day = (int)date('D', strtotime($formattedweekdate));
						$year = (int)date('Y', strtotime($formattedweekdate));
						//echo "Weeknummer: " . $week;
                            /* $data = array(
                                'dpr_no' => $importdata[1],
                                'report_date' => $formattedweekdate,
                                'medium' => $importdata[3],
                                'source_id' => $importdata[4],
                                'source_title' => $importdata[5],
                                'source_type' => $importdata[6],
                                'content_provider' => $importdata[7],
                                'no_of_correction' => $importdata[8],    
								'pub_year' => $importdata[9], 
								'volume' => $importdata[10], 
								'issue' => $importdata[11], 
								'article_iss' => $importdata[12], 
								'article_title' => $importdata[13], 
								'type_of_request' => $importdata[14], 
								'correction_field' => $importdata[15], 
								'correction_type' => $importdata[16], 
								'car_supplier' => $importdata[18], 
								'day' => $daysofweek,
								'week' => $week,
								'year' => $year,
                            ); */
							$data = array(
                                'dpr_no' => isset($record["DPR no."]) ? $record["DPR no."] : NULL, 
                                'report_date' => isset($record["Report Date"]) ? $formattedweekdate : NULL, 
                                'medium' => isset($record["Medium"]) ? $record["Medium"] : NULL,
                                'source_id' => isset($record["Source ID "]) ? $record["Source ID "] : NULL, 
                                'source_title' => isset($record["Source title "]) ? $record["Source title "] : NULL,
                                'source_type' => isset($record["Source type"]) ? $record["Source type"] : NULL,
                                'content_provider' => isset($record["Content provider"]) ? $record["Content provider"] : NULL,
                                'no_of_correction' => isset($record["No. of Correction"]) ? $record["No. of Correction"] : NULL,    
								'pub_year' => isset($record["Pub year"]) ? $record["Pub year"] : NULL, 
								'volume' => isset($record["Volume "]) ? $record["Volume "] : NULL, 
								'issue' => isset($record["Issue"]) ? $record["Issue"] : NULL, 
								'article_iss' => isset($record["Article/Iss"]) ? $record["Article/Iss"] : NULL, 
								'article_title' => isset($record["Article title"]) ? $record["Article title"] : NULL, 
								'type_of_request' => isset($record["Type of request"]) ? $record["Type of request"] : NULL,  
								'correction_field' => isset($record["Correction Field"]) ? $record["Correction Field"] : NULL, 
								'correction_type' => isset($record["Correction Type"]) ? $record["Correction Type"] : NULL, 
								'car_supplier' => isset($record["CAR Supplier"]) ? $record["CAR Supplier"] : NULL, 
								'day' => isset($record["Report Date"]) ? $daysofweek : NULL, 
								'week' => isset($record["Report Date"]) ? $week : NULL, 
								'year' => isset($record["Report Date"]) ? $year : NULL,
                            );
							 
                            $data['created_date'] = $current_date;
							//$this->insert_ignore($data);
                            $insert = $this->Uploadfile_model->insertCSV($data);
                        }
                        $i++;
                    }

                    fclose($file);
					$this->session->set_flashdata('success', 'Your '. $_FILES['file']['name'] . ' uploaded successfully!');
                    redirect('Uploadfile/index');
                } else {
                    $this->session->set_flashdata('error', 'Problem in uploading the file');
                    redirect('Uploadfile/index');
                }
            }
        } catch (Exception $e) {
            echo __LINE__ . '-----' . __FILE__ . '-----';
            echo "<pre>";
            print_r($e);
            log_message('error', $e);
            die;
        }

    }

/*     protected function insert_ignore(array $data) {
        $_prepared = array();
        foreach ($data as $col => $val)
            $_prepared[$this->db->_escape_identifiers($col)] = $this->db->escape($val); 
        $this->db->query('INSERT IGNORE INTO `tbl_enseignes` ('.implode(',',array_keys($_prepared)).') VALUES('.implode(',',array_values($_prepared)).');');
    } */



}
