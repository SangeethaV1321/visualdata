<?php if(!defined('BASEPATH')) exit('No direct script access allowed');

require APPPATH . '/libraries/BaseController.php';

/**
 * Class : User (UserController)
 * User Class to control all user related operations.
 * @author : Kishor Mali
 * @version : 1.1
 * @since : 15 November 2016
 */
class Pieonclick extends BaseController
{
    /**
     * This is default constructor of the class
     */
    public function __construct()
    {
        parent::__construct();
		$this->load->model('pieonclick_model');
        $this->isLoggedIn();   
    }
    
    /**
     * This function used to load the first screen of the user
     */
    public function index()
    {
        $this->global['pageTitle'] = 'Data correction - Line Chart';
		if(isset($_POST["from_week"])){
			$data['period'] = $_POST["from_week"];
		}
		else{
			$data['period'] = '';
		}
		if(isset($_POST["to_week"])){
			$data['periode'] = $_POST["to_week"];
		}
		else{
			$data['periode'] = '';
		}
		
		$data['ct'] = 'Data correction';
		$data['car_supplier'] = $this->pieonclick_model->car_supplier();
		$data['displaysupply'] = $this->pieonclick_model->display_supplier();
		$data['display_bar_supplier'] = $this->pieonclick_model->display_bar_supplier();
		$this->load->library('pagination');
        $this->loadViews("pieOnclickdc", $this->global, $data , NULL); 
    }
	
    /**
     * This function used to load the first screen of the user
     */
    public function mc()
    {
        $this->global['pageTitle'] = 'Missing content - Line Chart';
		if(isset($_POST["from_week"])){
			$data['period'] = $_POST["from_week"];
		}
		else{
			$data['period'] = '';
		}
		if(isset($_POST["to_week"])){
			$data['periode'] = $_POST["to_week"];
		}
		else{
			$data['periode'] = '';
		}
		
		$data['ct'] = 'Missing content';
		$data['car_supplier'] = $this->pieonclick_model->car_supplier();
		$data['displaysupply'] = $this->pieonclick_model->display_supplier();
		$this->load->library('pagination');
        $this->loadViews("pieOnclickmc", $this->global, $data , NULL); 
    }	
}

?>