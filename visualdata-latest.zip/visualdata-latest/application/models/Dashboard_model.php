<?php if(!defined('BASEPATH')) exit('No direct script access allowed');

class Dashboard_model extends CI_Model 
   {  
      function __construct()  
      {  
         // Call the Model constructor  
         parent::__construct(); 
         $this->load->database(); 
      }  
	
	public function display_pie()
    {
		$this->db->select('COUNT(`dpr_id`) as dpr_week_count, tbl_dpr_report.car_supplier', FALSE);
        $this->db->from('tbl_dpr_report');
		$this->db->where('tbl_dpr_report.correction_type', 'Data correction');
        $this->db->group_by('tbl_dpr_report.car_supplier');
		$this->db->order_by('tbl_dpr_report.car_supplier', 'ASC');
        $car_supplier = $this->db->get();
        $res1 = $car_supplier->result_array();
		//echo $this->db->last_query();
		$countloop1 = 0;
		foreach ($res1 as $row1) {
		$countloop1++;
            $car_suppliers1[] = $row1['car_supplier'];
			$dpr1[] = $row1['dpr_week_count'];
        }
		$resultca['correction_dc'] = 'Data correction';
		for ($i = 0; $i <= $countloop1-1; $i++) {
			$resultca['car_suppliers_dc_'.$i] = $car_suppliers1[$i];
			$resultca['dpr_dc_'.$i] = $dpr1[$i]; 
		}
		
		$this->db->select('COUNT(`dpr_id`) as dpr_week_count, tbl_dpr_report.car_supplier', FALSE);
        $this->db->from('tbl_dpr_report');
		$this->db->where('tbl_dpr_report.correction_type', 'Missing content');
        $this->db->group_by('tbl_dpr_report.car_supplier');
		$this->db->order_by('tbl_dpr_report.car_supplier', 'ASC');
        $car_supplier = $this->db->get();
        $res2 = $car_supplier->result_array();
		//echo $this->db->last_query();
		
		$countloop2 = 0;
		foreach ($res2 as $row2) {
		$countloop2++;
            $car_suppliers2[] = $row2['car_supplier'];
			$dpr2[] = $row2['dpr_week_count'];
        } 
		
		$resultca['correction_mc'] = 'Missing content';
		for ($i = 0; $i <= $countloop2-1; $i++) {
			$resultca['car_suppliers_mc_'.$i] = $car_suppliers2[$i];
			$resultca['dpr_mc_'.$i] = $dpr2[$i]; 
		} 
        return $resultca;
    }
}
 