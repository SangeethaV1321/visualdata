<?php if(!defined('BASEPATH')) exit('No direct script access allowed');

class Uploadfile_model extends CI_Model
{
    public function insertCSV($data) {		 
		$this->db->insert('tbl_dpr_report', $data);
		return TRUE;
/* 		$cadena_query = $this->db->insert_string('tbl_dpr_report', $data);
		$query1 = str_replace('INSERT INTO', 'INSERT IGNORE INTO', $cadena_query);
		$this->db->query($query1);
		return TRUE; */
    }

	public function view_data(){
		    $this->db->select('*', FALSE);        
            $this->db->from('tbl_dpr_report');
            $query_result = $this->db->get();
			$result = $query_result->result_array();
			return $result;
    }		
	
}