<?php if(!defined('BASEPATH')) exit('No direct script access allowed');
//session_start();
class Pieonclick_model extends CI_Model 
   {  
      function __construct()  
      {  
         // Call the Model constructor  
         parent::__construct(); 
         $this->load->database(); 
      }  
	  
	public function display_graph($supply_name)
    {
		if(isset($_POST["from_week"])){
			$from_week = $_POST["from_week"];
		}
		else{
			$from_week = '';
		}
		if(isset($_POST["to_week"])){
			$to_week = $_POST["to_week"];
		}
		else{
			$to_week = '';
		}
		
        $date = new DateTime();
		if (!empty($from_week)) {
            $weeka = $from_week;
            //$year = $date->format("Y");
        } else {
            $weeka = $date->format("W");
            //$year = $date->format("Y");
        }
        if (!empty($to_week)) {
            $weekb = $to_week;
            //$year = $date->format("Y");
        } else {
            $weekb = $date->format("W");
            //$year = $date->format("Y");
        }

		
		$this->db->select('COUNT(`dpr_id`) as dpr_week_count, tbl_dpr_report.week as semi,  tbl_dpr_report.car_supplier as supplier', FALSE);
        $this->db->from('tbl_dpr_report');
		$this->db->where('tbl_dpr_report.week >=', $weeka); 
        $this->db->where('tbl_dpr_report.week <=', $weekb);
        $this->db->where('tbl_dpr_report.correction_type', 'Data correction');
		$this->db->where_in('tbl_dpr_report.car_supplier', $supply_name);
        $this->db->group_by('tbl_dpr_report.week');
        $this->db->order_by('tbl_dpr_report.week', 'ASC');
        $query_result1 = $this->db->get();
        $result1 = $query_result1->result_array();
		//echo $this->db->last_query();
		//if(empty($query_result1->result())){
		if($weeka >= $weekb){
			//$resultArray1 = array("1" => 86, "2" => 85, "3" => 113);
			$week1 = array();
				$week1[1] = 0;

			for ($i = 1; $i <= 1; $i++) {
				if (in_array($i, array_keys($week1))) {
					$resultArray1[$i] = $week1[$i];
				} else {
					$resultArray1[$i] = 0;
				}
			}
		} else {
			$week1 = array();
			foreach ($result1 as $valHebdo1) {
					$week1[$valHebdo1['semi']] = $valHebdo1['dpr_week_count'];
			}

			//print_r($week1); echo "<br>";
			for ($i = $weeka; $i <= $weekb; $i++) {
				if (in_array($i, array_keys($week1))) {
					$resultArray1[$i] = $week1[$i];
				} else {
					$resultArray1[$i] = 0;
				}
			} 
		}
		
		
		//echo implode(",", $resultArray1); echo "<br>";
		$this->db->select('COUNT(`dpr_id`) as dpr_week_count, tbl_dpr_report.week as semi,  tbl_dpr_report.car_supplier as supplier', FALSE);
        $this->db->from('tbl_dpr_report');
        $this->db->where('tbl_dpr_report.week >=', $weeka); 
        $this->db->where('tbl_dpr_report.week <=', $weekb);
        $this->db->where('tbl_dpr_report.correction_type', 'Missing content');
		$this->db->where_in('tbl_dpr_report.car_supplier', $supply_name);
        $this->db->group_by('tbl_dpr_report.week');
        $this->db->order_by('tbl_dpr_report.week', 'ASC');
        $query_result2 = $this->db->get();
        $result2 = $query_result2->result_array();
		
		//if(empty($query_result2->result())){
		if($weeka >= $weekb){
			//$resultArray2 = array("1" => 86, "2" => 85, "3" => 113);
			$week2 = array();
				$week2[1] = 0;

			for ($i = 1; $i <= 1; $i++) {
				if (in_array($i, array_keys($week2))) {
					$resultArray2[$i] = $week2[$i];
				} else {
					$resultArray2[$i] = 0;
				}
			}
		} else {
			$week2 = array();
			foreach ($result2 as $valHebdo2) {
					$week2[$valHebdo2['semi']] = $valHebdo2['dpr_week_count'];
			}

			//print_r($week2); 
			for ($i = $weeka; $i <= $weekb; $i++) {
				if (in_array($i, array_keys($week2))) {
					$resultArray2[$i] = $week2[$i];
				} else {
					$resultArray2[$i] = 0;
				}
			}  
		}
		
		$resultca['maxVal_dc'] = abs(floor(max($resultArray1)));
        $resultca['minVal_dc'] = floor(min($resultArray1));    
        $resultca['td_dc'] = implode(",", $resultArray1);
		
        $resultca['maxVal_mc'] = abs(floor(max($resultArray2)));
        $resultca['minVal_mc'] = floor(min($resultArray2));    
        $resultca['td_mc'] = implode(",", $resultArray2);
		$resultca['supplier'] = $supply_name;
        return $resultca;
    }
	
	public function car_supplier()
    {
		$this->db->select('tbl_dpr_report.car_supplier', FALSE);
        $this->db->from('tbl_dpr_report');
        $this->db->group_by('tbl_dpr_report.car_supplier');
        $car_supplier = $this->db->get();
        $res = $car_supplier->result_array();
		
		foreach ($res as $row) {
            $car_suppliers[] = $row['car_supplier'];
        }
		
		if(isset($_POST["from_week"])){
			$from_week = $_POST["from_week"];
		}
		else{
			$from_week = '';
		}
		if(isset($_POST["to_week"])){
			$to_week = $_POST["to_week"];
		}
		else{
			$to_week = '';
		}
		
        $date = new DateTime();
		if (!empty($from_week)) {
            $weeka = $from_week;
        } else {
            $weeka = $date->format("W");
        }
        if (!empty($to_week)) {
            $weekb = $to_week;
        } else {
            $weekb = $date->format("W");
        }
		
		$this->db->select('COUNT(tbl_dpr_report.dpr_id) as dpr_week_count, tbl_dpr_report.week as semi, tbl_dpr_report.car_supplier as supplier', FALSE);
        $this->db->from('tbl_dpr_report');
        $this->db->where('tbl_dpr_report.week >=', $weeka); 
        $this->db->where('tbl_dpr_report.week <=', $weekb);
        $this->db->where('tbl_dpr_report.correction_type', 'Data correction');
        $this->db->where_in('tbl_dpr_report.car_supplier', $car_suppliers);
        $this->db->group_by('tbl_dpr_report.car_supplier,tbl_dpr_report.week');
        $this->db->order_by('dpr_week_count', 'ASC');
        $query_resultant1 = $this->db->get();
        $resultset1 = $query_resultant1->result_array();
		//echo $this->db->last_query();
		
		//if(empty($query_resultant1->result())){
		if($weeka >= $weekb){
			//$resultArray1 = array("1" => 86, "2" => 85, "3" => 113);	
			$week1 = array();
				$week1[1] = 0;

			for ($i = 1; $i <= 1; $i++) {
				if (in_array($i, array_keys($week1))) {
					$resultArray1[$i] = $week1[$i];
				} else {
					$resultArray1[$i] = 0;
				}
			}
			
		} else {
			$week1 = array();
			foreach ($resultset1 as $valHebdo1) {
					$week1[$valHebdo1['semi']] = $valHebdo1['dpr_week_count'];
			}
			for ($i = $weeka; $i <= $weekb; $i++) {
				if (in_array($i, array_keys($week1))) {
					$resultArray1[$i] = $week1[$i];
				} else {
					$resultArray1[$i] = 0;
				}
			}
		}

		  
		//print_R($resultArray1);
		$this->db->select('COUNT(tbl_dpr_report.dpr_id) as dpr_week_count, tbl_dpr_report.week as semi, tbl_dpr_report.car_supplier as supplier', FALSE);
        $this->db->from('tbl_dpr_report');
        $this->db->where('tbl_dpr_report.week >=', $weeka); 
        $this->db->where('tbl_dpr_report.week <=', $weekb);
        $this->db->where('tbl_dpr_report.correction_type', 'Missing content');
        $this->db->where_in('tbl_dpr_report.car_supplier', $car_suppliers);
        $this->db->group_by('tbl_dpr_report.car_supplier,tbl_dpr_report.week');
        $this->db->order_by('dpr_week_count', 'ASC');
        $query_resultant2 = $this->db->get();
        $resultset2 = $query_resultant2->result_array();
		//echo $this->db->last_query();
		//if(empty($query_resultant2->result())){
		if($weeka >= $weekb){
			//$resultArray2 = array("1" => 86, "2" => 85, "3" => 113);
			//echo "yes";
			$week2 = array();
				$week2[1] = 0;

			for ($i = 1; $i <= 1; $i++) {
				if (in_array($i, array_keys($week2))) {
					$resultArray2[$i] = $week2[$i];
				} else {
					$resultArray2[$i] = 0;
				}
			}
		} else {
			$week2 = array();
			foreach ($resultset2 as $valHebdo2) {
					$week2[$valHebdo2['semi']] = $valHebdo2['dpr_week_count'];
			}
			for ($i = $weeka; $i <= $weekb; $i++) {
				if (in_array($i, array_keys($week2))) {
					$resultArray2[$i] = $week2[$i];
				} else {
					$resultArray2[$i] = 0;
				}
			} 
		}
              

		$resultca['maxVal_dc'] = abs(floor(max($resultArray1)));
        $resultca['minVal_dc'] = floor(min($resultArray1));  
		
        $resultca['maxVal_mc'] = abs(floor(max($resultArray2)));
        $resultca['minVal_mc'] = floor(min($resultArray2));    
        return $resultca;
    } 
	
	public function display_supplier()
    {
		$this->db->select('tbl_dpr_report.car_supplier', FALSE);
        $this->db->from('tbl_dpr_report');
        $this->db->group_by('tbl_dpr_report.car_supplier');
        $car_supplier = $this->db->get();
        $res = $car_supplier->result_array();
		
		foreach ($res as $row) {
            $car_suppliers[] = $row['car_supplier'];
        } 

		for ($i = 0; $i <= 3; $i++) {
			$temp[] = $this->display_graph($car_suppliers[$i]);
			foreach ($temp as $row) {
				$resultca['max_dc_'.$i] = $row['maxVal_dc'];
				$resultca['min_dc_'.$i] = $row['minVal_dc'];
				$resultca['tdtot_dc_'.$i] = $row['td_dc'];
				
				$resultca['max_mc_'.$i] = $row['maxVal_mc'];
				$resultca['min_mc_'.$i] = $row['minVal_mc'];
				$resultca['tdtot_mc_'.$i] = $row['td_mc'];
				
				$resultca['supplier_'.$i] = $car_suppliers[$i];
			}
		}
        return $resultca;
    }
	
public function display_bar($supply_name)
    {
		$this->db->select('COUNT(`dpr_id`) as dpr_week_count, tbl_dpr_report.correction_field as corrections,  tbl_dpr_report.car_supplier as supplier', FALSE);
        $this->db->from('tbl_dpr_report');
		$this->db->where_in('tbl_dpr_report.car_supplier', $supply_name);
        $this->db->group_by('tbl_dpr_report.correction_field');
        $this->db->order_by('tbl_dpr_report.correction_field', 'ASC');
        $query_result = $this->db->get();
        $result = $query_result->result_array();
		//echo $this->db->last_query();
 
		$corrections_arr1 = array();
        foreach ($result as $valHebdo) {
            $corrections_arr1[$valHebdo['corrections']] = $valHebdo['dpr_week_count'];		
        }	 	    
		$temp[] = $this->corrections_list();
		$correction_arr2 = $temp[0]['correction_withoutquotes'];
		$corrections_arr2 = explode(",",$correction_arr2);
		$array_new = [];
		
		foreach($corrections_arr2 as $key){
			if(array_key_exists($key, $corrections_arr1))
			{
				$array_new[$key] = $corrections_arr1[$key];
			}
			else {
				$array_new[$key] = 0;
			}
			if($array_new[$key] <= 10)
			{
				unset($array_new[$key]);
			}  						
		}		
	
	    $array_keys = array_keys($array_new);

		$resultca['corrections'] = "'" . implode("','", $array_keys) . "'";
		$resultca['corrections_without_quotes'] = implode(",", $array_keys);
        $resultca['td'] = implode(",", $array_new);
		$resultca['supplier'] = $supply_name;
        return $resultca;
    }

	public function display_bar_supplier()
    {
		$this->db->select('tbl_dpr_report.car_supplier', FALSE);
        $this->db->from('tbl_dpr_report');
        $this->db->group_by('tbl_dpr_report.car_supplier');
        $car_supplier = $this->db->get();
        $res = $car_supplier->result_array();
		$count_loop = 0;
		$temparr = [];
		$woquotes = [];
		foreach ($res as $row) {
		$count_loop++;
            $car_suppliers[] = $row['car_supplier'];
        } 

		for ($i = 0; $i <= $count_loop-1; $i++) {
			$temp[] = $this->display_bar($car_suppliers[$i]);
			$max = '';
			$max_wo = '';
			//if($i == 3){ 
			foreach ($temp as $row) {
				$temparr[$row['corrections']] = $row['corrections'];
				$temparr1[$row['corrections_without_quotes']] = $row['corrections_without_quotes']; 
			}
			/*   echo "<pre>";
			print_r($temp);
			print_r($temparr);  */
			$maxlen = 0;
			foreach ($temparr as $elm) {
				$len = strlen($elm);

				if ($len > $maxlen) {
					$maxlen = $len;
					$max = $elm;             
				}
			}
			$maxlen1 = 0;
			foreach ($temparr1 as $elm1) {
				$len1 = strlen($elm1);

				if ($len1 > $maxlen1) {
					$maxlen1 = $len1;
					$max_wo = $elm1;             
				}
			}
			//}	
			
			foreach ($temp as $row) {
				//$resultca['corrections'] = $row['corrections'];
				$resultca['corrections'] = $max;
				$resultca['tdtot_'.$i] = $row['td'];
				$resultca['supplier_'.$i] = $car_suppliers[$i];
			}
		
			//$_SESSION["maxstring"] = $max_wo;
		}
        return $resultca;
    }
	
	public function corrections_list()
    {
		$this->db->select('COUNT(`dpr_id`) as dpr_week_count, tbl_dpr_report.correction_field as corrections', FALSE);
        $this->db->from('tbl_dpr_report');
        $this->db->group_by('tbl_dpr_report.correction_field');
		$this->db->order_by('tbl_dpr_report.correction_field', 'ASC');
        $supplier_count = $this->db->get();
        $res = $supplier_count->result_array();
		
		foreach ($res as $row) {
            $corrections_array[] = $row['corrections'];
			$dpr[] = $row['dpr_week_count'];
        } 

		$resultca['corrections'] = "'" . implode("','", $corrections_array) . "'";
		$resultca['correction_withoutquotes'] = implode(",", $corrections_array);
        $resultca['maxVal'] = abs(floor(max($dpr)));
        $resultca['minVal'] = floor(min($dpr));    
        return $resultca;
    }  	
}
 