<?php if(!defined('BASEPATH')) exit('No direct script access allowed');
//session_start();
class Dashboard_model extends CI_Model 
   {  
      function __construct()  
      {  
         // Call the Model constructor  
         parent::__construct(); 
         $this->load->database(); 
      }  
	  
	public function display_graph($supply_name)
    {
		if(isset($_POST["semaine"])){
			$semaine = $_POST["semaine"];
		}
		else{
			$semaine = '';
		}
		if(isset($_POST["correction_type"])){
			$correction_type = $_POST["correction_type"];
		}
		else{
			$correction_type = '';
		}
        $date = new DateTime();
        if (!empty($semaine)) {
            $week = $semaine;
            $year = $date->format("Y");
        } else {
            $week = $date->format("W");
            $year = $date->format("Y");
        }

		
		$this->db->select('COUNT(`dpr_id`) as dpr_week_count, tbl_dpr_report.week as semi,  tbl_dpr_report.car_supplier as supplier', FALSE);
        $this->db->from('tbl_dpr_report');
        $this->db->where('tbl_dpr_report.week <=', $week);
        $this->db->where('tbl_dpr_report.correction_type', $correction_type);
		$this->db->where_in('tbl_dpr_report.car_supplier', $supply_name);
        $this->db->group_by('tbl_dpr_report.week');
        $this->db->order_by('tbl_dpr_report.week', 'ASC');
        $query_result = $this->db->get();
        $result = $query_result->result_array();
		//echo $this->db->last_query();
		
//$mesure = $_POST["mesure"];
        $week1 = array();
        foreach ($result as $valHebdo) {
                $week1[$valHebdo['semi']] = $valHebdo['dpr_week_count'];
        }

		//print_r($week1); 
        for ($i = 1; $i <= $week; $i++) {
            if (in_array($i, array_keys($week1))) {
                $resultArray[$i] = $week1[$i];
            } else {
                $resultArray[$i] = 0;
            }
        }       

        $resultca['maxVal'] = abs(floor(max($resultArray)));
        $resultca['minVal'] = floor(min($resultArray));    
        $resultca['td'] = implode(",", $resultArray);
		$resultca['supplier'] = $supply_name;
        return $resultca;
    }
	
	public function car_supplier()
    {
		$this->db->select('tbl_dpr_report.car_supplier', FALSE);
        $this->db->from('tbl_dpr_report');
        $this->db->group_by('tbl_dpr_report.car_supplier');
        $car_supplier = $this->db->get();
        $res = $car_supplier->result_array();
		
		foreach ($res as $row) {
            $car_suppliers[] = $row['car_supplier'];
        }   
		if(isset($_POST["semaine"])){
			$semaine = $_POST["semaine"];
		}
		else{
			$semaine = '';
		}
		if(isset($_POST["correction_type"])){
			$correction_type = $_POST["correction_type"];
		}
		else{
			$correction_type = '';
		}
        $date = new DateTime();
        if (!empty($semaine)) {
            $week = $semaine;
            $year = $date->format("Y");
        } else {
            $week = $date->format("W");
            $year = $date->format("Y");
        }

		
		$this->db->select('COUNT(tbl_dpr_report.dpr_id) as dpr_week_count, tbl_dpr_report.week as semi, tbl_dpr_report.car_supplier as supplier', FALSE);
        $this->db->from('tbl_dpr_report');
        $this->db->where('tbl_dpr_report.week <=', $week);
        $this->db->where('tbl_dpr_report.correction_type', $correction_type);
        $this->db->where_in('tbl_dpr_report.car_supplier', $car_suppliers);
        $this->db->group_by('tbl_dpr_report.car_supplier,tbl_dpr_report.week');
        $this->db->order_by('dpr_week_count', 'ASC');
        $query_resultant = $this->db->get();
        $resultset = $query_resultant->result_array();


        $week1 = array();
        foreach ($resultset as $valHebdo) {
                $week1[$valHebdo['semi']] = $valHebdo['dpr_week_count'];
        }
        for ($i = 1; $i <= $week; $i++) {
            if (in_array($i, array_keys($week1))) {
                $resultArray[$i] = $week1[$i];
            } else {
                $resultArray[$i] = 0;
            }
        }       

        $resultca['maxVal'] = abs(floor(max($resultArray)));
        $resultca['minVal'] = floor(min($resultArray));    
        return $resultca;
    } 
	
	public function display_supplier()
    {
		$this->db->select('tbl_dpr_report.car_supplier', FALSE);
        $this->db->from('tbl_dpr_report');
        $this->db->group_by('tbl_dpr_report.car_supplier');
        $car_supplier = $this->db->get();
        $res = $car_supplier->result_array();
		
		foreach ($res as $row) {
            $car_suppliers[] = $row['car_supplier'];
        } 

		for ($i = 0; $i <= 3; $i++) {
			$temp[] = $this->display_graph($car_suppliers[$i]);
			foreach ($temp as $row) {
				$resultca['max_'.$i] = $row['maxVal'];
				$resultca['min_'.$i] = $row['minVal'];
				$resultca['tdtot_'.$i] = $row['td'];
				$resultca['supplier_'.$i] = $car_suppliers[$i];
			}
		}
        return $resultca;
    }

	public function display_bar($supply_name)
    {
		$this->db->select('COUNT(`dpr_id`) as dpr_week_count, tbl_dpr_report.correction_field as corrections,  tbl_dpr_report.car_supplier as supplier', FALSE);
        $this->db->from('tbl_dpr_report');
		$this->db->where_in('tbl_dpr_report.car_supplier', $supply_name);
        $this->db->group_by('tbl_dpr_report.correction_field');
        $this->db->order_by('tbl_dpr_report.correction_field', 'ASC');
        $query_result = $this->db->get();
        $result = $query_result->result_array();
		//echo $this->db->last_query();
 
		$corrections_arr1 = array();
        foreach ($result as $valHebdo) {
            $corrections_arr1[$valHebdo['corrections']] = $valHebdo['dpr_week_count'];		
        }	 	    
		$temp[] = $this->corrections_list();
		$correction_arr2 = $temp[0]['correction_withoutquotes'];
		$corrections_arr2 = explode(",",$correction_arr2);

		 /* $x_string = $_SESSION["maxstring"];
		$sess_x_val = explode(",",$x_string); */	
		$array_new = [];
		
/* if(empty($sess_x_val)) {  */
	foreach($corrections_arr2 as $key){
		if(array_key_exists($key, $corrections_arr1))
		{
			$array_new[$key] = $corrections_arr1[$key];
		}
		else {
			$array_new[$key] = 0;
		}
		if($array_new[$key] <= 10)
		{
			unset($array_new[$key]);
		}  						
	}
/*  }
else{ 
	foreach($sess_x_val as $key){
		if(array_key_exists($key, $corrections_arr1))
		{
			$array_new[$key] = $corrections_arr1[$key];
		}
		else {
			$array_new[$key] = 0;
		}						
	} 
}  */ 
	
		
		
	
	 $array_keys = array_keys($array_new);
	/*   echo "<pre>";
	 print_r($array_new); */ 
	 
	 
		$resultca['corrections'] = "'" . implode("','", $array_keys) . "'";
		$resultca['corrections_without_quotes'] = implode(",", $array_keys);
        $resultca['td'] = implode(",", $array_new);
		$resultca['supplier'] = $supply_name;
        return $resultca;
    }

	public function display_bar_supplier()
    {
		$this->db->select('tbl_dpr_report.car_supplier', FALSE);
        $this->db->from('tbl_dpr_report');
        $this->db->group_by('tbl_dpr_report.car_supplier');
        $car_supplier = $this->db->get();
        $res = $car_supplier->result_array();
		$count_loop = 0;
		$temparr = [];
		$woquotes = [];
		foreach ($res as $row) {
		$count_loop++;
            $car_suppliers[] = $row['car_supplier'];
        } 

		for ($i = 0; $i <= $count_loop-1; $i++) {
			$temp[] = $this->display_bar($car_suppliers[$i]);
			$max = '';
			$max_wo = '';
			//if($i == 3){ 
			foreach ($temp as $row) {
				$temparr[$row['corrections']] = $row['corrections'];
				$temparr1[$row['corrections_without_quotes']] = $row['corrections_without_quotes']; 
			}
			/*   echo "<pre>";
			print_r($temp);
			print_r($temparr);  */
			$maxlen = 0;
			foreach ($temparr as $elm) {
				$len = strlen($elm);

				if ($len > $maxlen) {
					$maxlen = $len;
					$max = $elm;             
				}
			}
			$maxlen1 = 0;
			foreach ($temparr1 as $elm1) {
				$len1 = strlen($elm1);

				if ($len1 > $maxlen1) {
					$maxlen1 = $len1;
					$max_wo = $elm1;             
				}
			}
			//}	
			
			foreach ($temp as $row) {
				//$resultca['corrections'] = $row['corrections'];
				$resultca['corrections'] = $max;
				$resultca['tdtot_'.$i] = $row['td'];
				$resultca['supplier_'.$i] = $car_suppliers[$i];
			}

			/*  echo $max_wo;
			echo "<br>";  */
		
			//$_SESSION["maxstring"] = $max_wo;
		}
		
		
		    /* echo "<pre>";
			//s echo $temp[0]['corrections'];
			print_r($temp);
			echo count($temp);  */
        return $resultca;
    }
	
	public function corrections_list()
    {
		$this->db->select('COUNT(`dpr_id`) as dpr_week_count, tbl_dpr_report.correction_field as corrections', FALSE);
        $this->db->from('tbl_dpr_report');
        $this->db->group_by('tbl_dpr_report.correction_field');
		$this->db->order_by('tbl_dpr_report.correction_field', 'ASC');
        $supplier_count = $this->db->get();
        $res = $supplier_count->result_array();
		
		foreach ($res as $row) {
            $corrections_array[] = $row['corrections'];
			$dpr[] = $row['dpr_week_count'];
        } 
		
     /* foreach($corrections_array as $index => $string) {
        if (strpos($string, $keyword) !== FALSE){
		//$array_pos[] = $string;
        }
		else {
		$array_pos[] = $string;
		}		
    }   */
	/* echo "<pre>";
	print_r($array_pos);
	exit; */

		$resultca['corrections'] = "'" . implode("','", $corrections_array) . "'";
		$resultca['correction_withoutquotes'] = implode(",", $corrections_array);
        $resultca['maxVal'] = abs(floor(max($dpr)));
        $resultca['minVal'] = floor(min($dpr));    
        return $resultca;
    }  
	
	public function display_pie()
    {
		if(isset($_POST["correction_type"])){
			$correction_type = $_POST["correction_type"];
		}
		else{
			$correction_type = '';
		}
		$this->db->select('COUNT(`dpr_id`) as dpr_week_count, tbl_dpr_report.car_supplier', FALSE);
        $this->db->from('tbl_dpr_report');
		$this->db->where('tbl_dpr_report.correction_type', $correction_type);
        $this->db->group_by('tbl_dpr_report.car_supplier');
		$this->db->order_by('tbl_dpr_report.car_supplier', 'ASC');
        $car_supplier = $this->db->get();
        $res = $car_supplier->result_array();
		//echo $this->db->last_query();
		
		$countloop = 0;
		foreach ($res as $row) {
		$countloop++;
            $car_suppliers[] = $row['car_supplier'];
			$dpr[] = $row['dpr_week_count'];
        } 
		
		//print_r($car_suppliers); 
		$resultca['correction'] = $correction_type;
		for ($i = 0; $i <= $countloop-1; $i++) {
			$resultca['car_suppliers_'.$i] = $car_suppliers[$i];
			$resultca['dpr_'.$i] = $dpr[$i]; 
		}
		/* $resultca['corrections'] = "'" . implode("','", $corrections_array) . "'";
		$resultca['correction_withoutquotes'] = implode(",", $corrections_array);
        $resultca['maxVal'] = abs(floor(max($dpr)));
        $resultca['minVal'] = floor(min($dpr));   */  
        return $resultca;
    }
}
 