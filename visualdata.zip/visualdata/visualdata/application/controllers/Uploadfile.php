<?php if(!defined('BASEPATH')) exit('No direct script access allowed');
require APPPATH . '/libraries/BaseController.php';

class Uploadfile extends BaseController {
public function __construct()
{
    parent::__construct();
    //$this->load->helper('url');                    
    $this->load->model('Uploadfile_model');
	$this->isLoggedIn();  
}

public function index()
{   
	$this->global['pageTitle'] = 'CSV Upload';
	$this->loadViews("uploadfile", $this->global, NULL , NULL);
}

	////////////////// Import subscriber emails ////////////////////////////////
/* public function importbulkemail(){
	$this->loadViews('upload');
} */

    public function import()
    {
        set_time_limit(0);
        error_reporting(E_ALL);
        try {
            if (isset($_POST["import"])) {
                $filename = $_FILES["file"]["tmp_name"];
                if ($_FILES["file"]["size"] > 0) {
                    $file = fopen($filename, "r");
                    $i = 0;
                    //while (($importdata = fgetcsv($file, 10000, ",")) !== FALSE) {
                    while (($importdata = fgetcsv($file)) !== FALSE) {
                        if($i > 0) {
                            $data = array(
                                'dpr_no' => $importdata[0],
                                'report_date' => $importdata[1],
                                'medium' => $importdata[2],
                                'source_id' => $importdata[3],
                                'source_title' => $importdata[4],
                                'source_type' => $importdata[5],
                                'content_provider' => $importdata[6],
                                'no_of_correction' => $importdata[7],    
								'pub_year' => $importdata[8], 
								'volume' => $importdata[9], 
								'issue' => $importdata[10], 
								'article_iss' => $importdata[11], 
								'article_title' => $importdata[12], 
								'type_of_request' => $importdata[13], 
								'correction_field' => $importdata[14], 
								'correction_type' => $importdata[15], 
								'car_supplier' => $importdata[16] 
                            );
                           // $data['unique_key'] = $importdata[1].'_'.$importdata[2];
							//$this->insert_ignore($data);
                            $insert = $this->Uploadfile_model->insertCSV($data);
                        }
                        $i++;
                    }

                    fclose($file);
					$this->session->set_flashdata('success', 'Your file uploaded successfully');
                    redirect('Uploadfile/index');
                } else {
                    $this->session->set_flashdata('error', 'Problem in uploading the file');
                    redirect('Uploadfile/index');
                }
            }
        } catch (Exception $e) {
            echo __LINE__ . '-----' . __FILE__ . '-----';
            echo "<pre>";
            print_r($e);
            log_message('error', $e);
            die;
        }

    }

/*     protected function insert_ignore(array $data) {
        $_prepared = array();
        foreach ($data as $col => $val)
            $_prepared[$this->db->_escape_identifiers($col)] = $this->db->escape($val); 
        $this->db->query('INSERT IGNORE INTO `tbl_enseignes` ('.implode(',',array_keys($_prepared)).') VALUES('.implode(',',array_values($_prepared)).');');
    } */



}
