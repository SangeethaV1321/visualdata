<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        <i class="fa fa-tachometer" aria-hidden="true"></i> Dashboard
        <small>Control panel</small>
      </h1>
    </section>
    
<section class="content">
    <div class="row">
	</div>
<div class="row">
<div class="container-fluid">
<form method="post" id="week_submit" action="<?php echo base_url('pieOnclick') ?>">
	<!-- <h3 class="title1">Corrections :</h3> -->
    <div class="col-lg-3 col-md-6 col-sm-6 col-xs-12">
		<div class="item item-input">
			<span class="input-label">Week :</span>
			<label class="custom-select">
			<select name="semaine" id="periode">
				<option value="">Select the week</option>
				<?php  if(!isset($_POST["semaine"])){ ?>
				<?php      
				$date = new DateTime();
				echo $week = $date->format("W");
				?>
				<option value="<?php echo $week; ?>" <?php echo 'selected="selected"'; ?> ><?php echo $week; ?></option>
				<?php } else{ ?>
				<?php for ($i = 1; $i < 53; $i++) { ?>
					<option value="<?php echo $i; ?>" <?php if ($periode == $i) echo 'selected="selected"'; ?> ><?php echo $i; ?></option>
				<?php }  }   ?>
			</select>
			</label>
			
		</div>
	</div>
	<div class="col-lg-9 col-md-6 col-sm-6 col-xs-12"> 
		<div class="item item-input">
		<span class="input-label">Correction type :</span>
		<label class="custom-select">
			<select name="correction_type" id="correction_type">
				<option value="Data correction"<?php if ($ct == "Data correction") echo 'selected="selected"'; ?>>Data correction</option>
				<option value="Missing content"<?php if ($ct == "Missing content") echo 'selected="selected"'; ?>>Missing content</option>
			</select>
		</label>	
		</div>
	</div>
	<!-- <input type="submit" value="Submit" /> -->
</form>
</div>
</div>
</section>
<?php
$date = new DateTime();
$week = $date->format("W");
if (!empty($periode)) {
    $week = $periode;
} else {
    $week = $date->format("W");
}
array('1', '2', '3', '4', '5', '6', '7', '8', '9', '10', '11', '12', '13', '14', '15', '16', '17', '18', '19', '20', '21', '22', '23', '24', '25', '26', '27', '28', '29', '30', '31', '32', '33', '34', '35', '36', '37', '38', '39', '40', '41', '42', '43', '44', '45', '46', '47', '48', '49', '50', '51', '52');
$text = 'Week';
foreach (range('1', $week) as $letter) {
    $res[] = $text . $letter;
}
$week_value = "'" . implode("','", $res) . "'";

 $minimum_dc = $car_supplier['minVal_dc'];
 $maximum_dc = $car_supplier['maxVal_dc'];
	if($maximum_dc >= $minimum_dc) {
	echo $interval_dc = round(($maximum_dc/2),-2);
	} else {
	$interval_dc = round(($minimum_dc/2),-2);
	}

 $minimum_mc = $car_supplier['minVal_mc'];
 $maximum_mc = $car_supplier['maxVal_mc'];
	if($maximum_mc >= $minimum_mc) {
	$interval_mc = round(($maximum_mc/2),-2);
	} else {
	$interval_mc = round(($minimum_mc/2),-2);
	}	
	/* echo $minimum = $supplier_count['minVal'];
	echo $maximum = $supplier_count['maxVal']; */
	/* echo $display_bar_supplier['supplier_0']; */
	/* echo $display_bar_supplier['corrections'];  */

?>
<div id="container1a" style="min-width: 310px; height: auto; margin: 0 auto"></div>
<div id="container1b" style="min-width: 310px; height: auto; margin: 0 auto"></div>
<!-- <div id="container2a" onclick="window.location='<?php echo site_url('Pieonclick/dc'); ?>';" style="min-width: 310px; height: auto; margin: 0 auto"></div>
<div id="container2b" onclick="window.location='<?php echo site_url('Pieonclick/mc'); ?>';" style="min-width: 310px; height: auto; margin: 0 auto"></div>
<div id="container3" style="min-width: 310px; height: auto; margin: 0 auto"></div> -->
</div>



<?php
    if ( ! isset($_POST['semaine']) ) { // not submitted yet
?>
<script>
$(document).ready(function(){
	$("#week_submit").submit();
});  
</script>
<?php
    }
?>
<script type="text/javascript">
$("#periode").change(function () {
	$("#week_submit").submit();
});  
$("#correction_type").change(function () {
	//$request = $('option:selected', $(this)).val();
	$("#week_submit").submit();
	// window.location.href = "<?php echo site_url('accueil/casort'); ?>";
}); 
</script>

<script type="text/javascript">
$(document).ready(function () {
Highcharts.chart('container1a', {
	xAxis: {
		categories: [<?php echo $week_value;?>],
		tickInterval: '1',
		max: '<?php echo $week;?>',
		title: {
			text: 'Week Number'
		}
	},
	yAxis: {
		min: <?php echo $minimum_dc;?>,
		max: <?php echo $maximum_dc;?>,
		tickInterval: <?php echo $interval_dc;?>,
		title: {
			text: 'No. of DPRs'
		}
	},
	tooltip: {
		backgroundColor: '#000000',
		borderColor: '#000000',
		borderRadius: 10,
		borderWidth: 3,
		style:{color : '#fff'}
	},
	plotOptions: {
		spline: {
			lineWidth: 2,
			states: {
				hover: {
					lineWidth: 3
				}
			}
		}
	},
	title: {
		text: 'Data Correction',
		style: {
			 color: '#3c8dbc'
		  }
	},
	subtitle: {
        text: 'Weekly',
		style: {
			 color: '#3c8dbc'
		  }			
    },
	series: [{
		type: 'spline',
		name: '<?php echo $displaysupply['supplier_0']; ?>',
		data: [<?php echo $displaysupply['tdtot_dc_0'];?>]
	}, {
		type: 'spline',
		name: '<?php echo $displaysupply['supplier_1']; ?>',
		data: [<?php echo $displaysupply['tdtot_dc_1'];?>]
	}, {
		type: 'spline',
		name: '<?php echo $displaysupply['supplier_2']; ?>',
		data: [<?php echo $displaysupply['tdtot_dc_2'];?>]
	}, {
		type: 'spline',
		name: '<?php echo $displaysupply['supplier_3']; ?>',
		data: [<?php echo $displaysupply['tdtot_dc_3'];?>]
	}],
	colors: ['#7cb5ec', '#f15c80','#90ed7d', '#f7a35c']
});
Highcharts.chart('container1b', {
	xAxis: {
		categories: [<?php echo $week_value;?>],
		tickInterval: '1',
		max: '<?php echo $week;?>',
		title: {
			text: 'Week Number'
		}
	},
	yAxis: {
		min: <?php echo $minimum_mc;?>,
		max: <?php echo $maximum_mc;?>,
		tickInterval: <?php echo $interval_mc;?>,
		title: {
			text: 'No. of DPRs'
		}
	},
	tooltip: {
		backgroundColor: '#000000',
		borderColor: '#000000',
		borderRadius: 10,
		borderWidth: 3,
		style:{color : '#fff'}
	},
	plotOptions: {
		spline: {
			lineWidth: 2,
			states: {
				hover: {
					lineWidth: 3
				}
			}
		}
	},
	title: {
		text: 'Missing Content',
		style: {
			 color: '#3c8dbc'
		  }
	},
	subtitle: {
        text: 'Weekly',
		style: {
			 color: '#3c8dbc'
		  }			
    },
	series: [{
		type: 'spline',
		name: '<?php echo $displaysupply['supplier_0']; ?>',
		data: [<?php echo $displaysupply['tdtot_mc_0'];?>]
	}, {
		type: 'spline',
		name: '<?php echo $displaysupply['supplier_1']; ?>',
		data: [<?php echo $displaysupply['tdtot_mc_1'];?>]
	}, {
		type: 'spline',
		name: '<?php echo $displaysupply['supplier_2']; ?>',
		data: [<?php echo $displaysupply['tdtot_mc_2'];?>]
	}, {
		type: 'spline',
		name: '<?php echo $displaysupply['supplier_3']; ?>',
		data: [<?php echo $displaysupply['tdtot_mc_3'];?>]
	}],
	colors: ['#7cb5ec', '#f15c80','#90ed7d', '#f7a35c']
});
});
</script>