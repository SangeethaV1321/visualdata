<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        <i class="fa fa-upload" aria-hidden="true"></i> CSV Upload
      </h1>
    </section>
    
    <section class="content">
        <div class="row">
            <div class="admin_row equal_height">
		<br><br>
		<div align="center">
		<form action="<?php echo base_url(); ?>Uploadfile/import" method="post" name="upload_csv" enctype="multipart/form-data" class="import_form">
		<input type="file" name="file" id="file" class="import_file">
		<button type="submit" id="enseignes_import" name="import" title="Importer" class="import_btn btn btn-primary button-loading">Import Csv</button>
		</form>
		<br>
		<br>
		<a href="<?php echo base_url(); ?>sample.csv" title="Example of csv file">Example of csv file</a>
		<br><br>
	</div>
    <div class="loader"></div>
	<style type="text/css">
	${demo.css}
	</style>
</div>

        </div>
    </section>
</div>


<script type="text/javascript">
$(document).ready(function () {
	$(window).load(function() { 
		$('.loader').hide();
	});
	$(document).on("click", "#enseignes_import", function () {
		$('.loader').show();
		return true;
	}); 
});
</script>