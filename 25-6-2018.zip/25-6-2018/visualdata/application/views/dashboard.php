<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        <i class="fa fa-tachometer" aria-hidden="true"></i> Dashboard
        <small>Control panel</small>
      </h1>
    </section>
    
<section class="content">
    <div class="row">
	<!-- <div class="col-lg-3 col-xs-6">             
	  <div class="small-box bg-aqua">
		<div class="inner">
		  <h3>150</h3>
		  <p>New Tasks</p>
		</div>
		<div class="icon">
		  <i class="ion ion-bag"></i>
		</div>
		<a href="#" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
	  </div>
	</div>
	<div class="col-lg-3 col-xs-6">            
	  <div class="small-box bg-green">
		<div class="inner">
		  <h3>53<sup style="font-size: 20px">%</sup></h3>
		  <p>Completed Tasks</p>
		</div>
		<div class="icon">
		  <i class="ion ion-stats-bars"></i>
		</div>
		<a href="#" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
	  </div>
	</div>
	<div class="col-lg-3 col-xs-6">
	  <div class="small-box bg-yellow">
		<div class="inner">
		  <h3>44</h3>
		  <p>New User</p>
		</div>
		<div class="icon">
		  <i class="ion ion-person-add"></i>
		</div>
		<a href="<?php //echo base_url(); ?>userListing" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
	  </div>
	</div>
	<div class="col-lg-3 col-xs-6">
	  <div class="small-box bg-red">
		<div class="inner">
		  <h3>65</h3>
		  <p>Reopened Issue</p>
		</div>
		<div class="icon">
		  <i class="ion ion-pie-graph"></i>
		</div>
		<a href="#" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
	  </div>
	</div> -->
	</div>
<div class="row">
<div class="container-fluid">
<form method="post" id="week_submit" action="<?php echo base_url('dashboard') ?>">
	<!-- <h3 class="title1">Corrections :</h3> -->
    <div class="col-lg-3 col-md-6 col-sm-6 col-xs-12">
		<div class="item item-input">
			<span class="input-label">Week :</span>
			<select name="semaine" id="periode">
				<option value="">Select the week</option>
				<?php  if(!isset($_POST["semaine"])){ ?>
				<?php      
				$date = new DateTime();
				echo $week = $date->format("W");
				?>
				<option value="<?php echo $week; ?>" <?php echo 'selected="selected"'; ?> ><?php echo $week; ?></option>
				<?php } else{ ?>
				<?php for ($i = 1; $i < 53; $i++) { ?>
					<option value="<?php echo $i; ?>" <?php if ($periode == $i) echo 'selected="selected"'; ?> ><?php echo $i; ?></option>
				<?php }  }   ?>
			</select>
		</div>
	</div>
	<div class="col-lg-9 col-md-6 col-sm-6 col-xs-12"> 
		<div class="item item-input">
		<span class="input-label">Correction type :</span>
			<select name="correction_type" id="correction_type">
				<option value="DC"<?php if ($ct == "DC") echo 'selected="selected"'; ?>>Data correction</option>
				<option value="MC"<?php if ($ct == "MC") echo 'selected="selected"'; ?>>Missing content</option>
			</select>
		</div>
	</div>
	<!-- <input type="submit" value="Submit" /> -->
</form>
</div>
</div>
</section>
<?php
$date = new DateTime();
$week = $date->format("W");
if (!empty($periode)) {
    $week = $periode;
} else {
    $week = $date->format("W");
}
array('1', '2', '3', '4', '5', '6', '7', '8', '9', '10', '11', '12', '13', '14', '15', '16', '17', '18', '19', '20', '21', '22', '23', '24', '25', '26', '27', '28', '29', '30', '31', '32', '33', '34', '35', '36', '37', '38', '39', '40', '41', '42', '43', '44', '45', '46', '47', '48', '49', '50', '51', '52');
$text = 'Week';
foreach (range('1', $week) as $letter) {
    $res[] = $text . $letter;
}
$week_value = "'" . implode("','", $res) . "'";

 $minimum = $car_supplier['minVal'];
 $maximum = $car_supplier['maxVal'];
	if($maximum >= $minimum) {
	$interval = round(($maximum/2),-2);
	} else {
	$interval = round(($minimum/2),-2);
	}
	
	/* echo $minimum = $supplier_count['minVal'];
	echo $maximum = $supplier_count['maxVal']; */
	/* echo $display_bar_supplier['supplier_0']; */
	/* echo $display_bar_supplier['corrections'];  */

?>
<div id="container1" style="min-width: 310px; height: auto; margin: 0 auto"></div>
<div id="container2" style="min-width: 310px; height: auto; margin: 0 auto"></div>
<div id="container3" style="min-width: 310px; height: auto; margin: 0 auto"></div>
</div>



<?php
    if ( ! isset($_POST['semaine']) ) { // not submitted yet
?>
<script>
$(document).ready(function(){
	$("#week_submit").submit();
}); 
</script>
<?php
    }
?>
<script type="text/javascript">
$("#periode").change(function () {
	$("#week_submit").submit();
});  
$("#correction_type").change(function () {
	//$request = $('option:selected', $(this)).val();
	$("#week_submit").submit();
	// window.location.href = "<?php echo site_url('accueil/casort'); ?>";
}); 
</script>

<script type="text/javascript">
$(document).ready(function () {
Highcharts.chart('container1', {
	xAxis: {
		categories: [<?php echo $week_value;?>],
		tickInterval: '1',
		max: '<?php echo $week;?>',
		title: {
			text: 'Week Number'
		}
	},
	yAxis: {
		min: <?php echo $minimum;?>,
		max: <?php echo $maximum;?>,
		tickInterval: <?php echo $interval;?>,
		title: {
			text: 'No. of DPRs'
		}
	},
	tooltip: {
		backgroundColor: '#000000',
		borderColor: '#000000',
		borderRadius: 10,
		borderWidth: 3,
		style:{color : '#fff'}
	},
	plotOptions: {
		spline: {
			lineWidth: 2,
			states: {
				hover: {
					lineWidth: 3
				}
			}
		}
	},
	title: {
		text: '<?php 
				if ( $ct == 'DC' ) {
					echo 'Data Correction';
				} else {
					echo 'Missing Content';
				} ?>',
		style: {
			 color: '#3c8dbc'
		  }
	},
	series: [{
		type: 'spline',
		name: '<?php echo $displaysupply['supplier_0']; ?>',
		data: [<?php echo $displaysupply['tdtot_0'];?>]
	}, {
		type: 'spline',
		name: '<?php echo $displaysupply['supplier_1']; ?>',
		data: [<?php echo $displaysupply['tdtot_1'];?>]
	}, {
		type: 'spline',
		name: '<?php echo $displaysupply['supplier_2']; ?>',
		data: [<?php echo $displaysupply['tdtot_2'];?>]
	}, {
		type: 'spline',
		name: '<?php echo $displaysupply['supplier_3']; ?>',
		data: [<?php echo $displaysupply['tdtot_3'];?>]
	}],
	colors: ['#7cb5ec', '#f15c80','#90ed7d', '#f7a35c']
});

Highcharts.chart('container2', {
    chart: {
        type: 'pie',
        options3d: {
            enabled: true,
            alpha: 45
        }
    },
    title: {
        text: 'Supplier Performance',
		style: {
			 color: '#3c8dbc'
		  }
    },
    subtitle: {
        text: '<?php 
				if ( $display_pie['correction'] == 'DC' ) {
					echo 'Data Correction';
				} else {
					echo 'Missing Content';
				} ?>',
		style: {
			 color: '#3c8dbc'
		  }			
    },
    plotOptions: {
		pie: {
            innerSize: 100,
            depth: 45,
			allowPointSelect: true,
            cursor: 'pointer',
            dataLabels: {
                enabled: true,
                format: '<b>{point.name}</b>: {point.percentage:.1f} %',
                style: {
                    color: (Highcharts.theme && Highcharts.theme.contrastTextColor) || 'black'
                }
            },
            showInLegend: true
        }
    },
    series: [{
        name: '<?php 
				if ( $display_pie['correction'] == 'DC' ) {
					echo 'Data Correction';
				} else {
					echo 'Missing Content';
				} ?>',
        data: [
            ['<?php echo $display_pie['car_suppliers_0']; ?>', <?php echo $display_pie['dpr_0']; ?>],
            ['<?php echo $display_pie['car_suppliers_1']; ?>', <?php echo $display_pie['dpr_1']; ?>],
            ['<?php echo $display_pie['car_suppliers_2']; ?>', <?php echo $display_pie['dpr_2']; ?>],
            ['<?php echo $display_pie['car_suppliers_3']; ?>', <?php echo $display_pie['dpr_3']; ?>]
        ]
    }],
	colors: ['#7cb5ec', '#f15c80','#90ed7d', '#f7a35c']
});
    
Highcharts.chart('container3', {
    chart: {
        type: 'column'
    },
    title: {
        text: 'Data Corrections (> 30)',
		style: {
			 color: '#3c8dbc'
		  }
    },
    xAxis: {
        categories: [<?php echo $display_bar_supplier['corrections']; ?>],
        crosshair: true,
		title: {
            text: 'Correction Field'
        }
    },
    yAxis: {
        min: 0,
        title: {
            text: 'No. of DPRs'
        }
    },
    tooltip: {
        headerFormat: '<span style="font-size:10px">{point.key}</span><table>',
        pointFormat: '<tr><td style="color:{series.color};padding:0">{series.name}: </td>' +
            '<td style="padding:0"><b>{point.y}</b></td></tr>',
        footerFormat: '</table>',
        shared: true,
        useHTML: true,
		backgroundColor: '#000000',
		borderColor: '#000000',
		borderRadius: 10,
		borderWidth: 3,
		style:{color : '#fff'}
    },
    plotOptions: {
        column: {
            pointPadding: 0.2,
            borderWidth: 0
        }
    },
    series: [{
        name: '<?php echo $display_bar_supplier['supplier_0']; ?>',
        data: [<?php echo $display_bar_supplier['tdtot_0'];?>]

    }, {
        name: '<?php echo $display_bar_supplier['supplier_1']; ?>',
        data: [<?php echo $display_bar_supplier['tdtot_1'];?>]

    }, {
        name: '<?php echo $display_bar_supplier['supplier_2']; ?>',
        data: [<?php echo $display_bar_supplier['tdtot_2'];?>]

    }, {
        name: '<?php echo $display_bar_supplier['supplier_3']; ?>',
        data: [<?php echo $display_bar_supplier['tdtot_3'];?>]

    }],
	colors: ['#7cb5ec', '#f15c80','#90ed7d', '#f7a35c']
}); 


/* 
Highcharts.chart('container4', {
    chart: {
        type: 'pie',
        options3d: {
            enabled: true,
            alpha: 45,
            beta: 0
        }
    },
    title: {
        text: 'Browser market shares at a specific website, 2014'
    },
    tooltip: {
        pointFormat: '{series.name}: <b>{point.percentage:.1f}%</b>'
    },
    plotOptions: {
        pie: {
            allowPointSelect: true,
            cursor: 'pointer',
            depth: 35,
            dataLabels: {
                enabled: false,
                format: '{point.name}'
            },
            showInLegend: true
        }
    },
    series: [{
        type: 'pie',
        name: 'Browser share',
        data: [
            ['<?php echo $display_pie['car_suppliers_0']; ?>', <?php echo $display_pie['dpr_0']; ?>],
            ['<?php echo $display_pie['car_suppliers_1']; ?>', <?php echo $display_pie['dpr_1']; ?>],
            ['<?php echo $display_pie['car_suppliers_2']; ?>', <?php echo $display_pie['dpr_2']; ?>],
            ['<?php echo $display_pie['car_suppliers_3']; ?>', <?php echo $display_pie['dpr_3']; ?>]
        ]
    }]
}); */


/* Highcharts.chart('container1', {
	xAxis: {
		categories: [<?php echo $week_value;?>],
		tickInterval: '1',
		max: '<?php echo $week;?>'
	},
	yAxis: {
		min: <?php echo $minimum;?>,
		max: <?php echo $maximum;?>,
		tickInterval: <?php echo $interval;?>,
		title: {
			text: 'No. of DPRs'
		},
		minorGridLineWidth: 0,
		gridLineWidth: 0,
		alternateGridColor: null,
		 plotBands: [{
			from: <?php echo $maximum ;?>,
			to: <?php echo $maximum - $interval;?>,
			color: 'rgba(68, 170, 213, 0.1)'
		},{
			 from: 0,
			 to: <?php echo '-'.$interval;?>,
			 color: 'rgba(68, 170, 213, 0.1)'
		 },{
			 from: <?php echo '-'.($interval+$interval);?>,
			 to: <?php echo $minimum;?>,
			 color: 'rgba(68, 170, 213, 0.1)'
		 }]
	},
	tooltip: {
		valueSuffix: '%'
	},
	tooltip: {
		backgroundColor: '#000000',
		borderColor: '#000000',
		borderRadius: 10,
		borderWidth: 3,
		style:{color : '#fff'}
	},
	plotOptions: {
		spline: {
			lineWidth: 2,
			states: {
				hover: {
					lineWidth: 3
				}
			}
		}
	},
	title: {
		text: '<?php 
				if ( $ct == 'DC' ) {
					echo 'Data Correction';
				} else {
					echo 'Missing Content';
				} ?>',
		style: {
			 color: '#08619d'
		  }
	},
	series: [{
		type: 'spline',
		name: '<?php echo $displaysupply['supplier_0']; ?>',
		data: [<?php echo $displaysupply['tdtot_0'];?>]
	}, {
		type: 'spline',
		name: '<?php echo $displaysupply['supplier_1']; ?>',
		data: [<?php echo $displaysupply['tdtot_1'];?>]
	}, {
		type: 'spline',
		name: '<?php echo $displaysupply['supplier_2']; ?>',
		data: [<?php echo $displaysupply['tdtot_2'];?>]
	}, {
		type: 'spline',
		name: '<?php echo $displaysupply['supplier_3']; ?>',
		data: [<?php echo $displaysupply['tdtot_3'];?>]
	}]
}); */
});
</script>