<?php if(!defined('BASEPATH')) exit('No direct script access allowed');

class Dashboard_model extends CI_Model 
   {  
      function __construct()  
      {  
         // Call the Model constructor  
         parent::__construct(); 
         $this->load->database(); 
      }  
	  
	public function display_graph($supply_name)
    {
		if(isset($_POST["semaine"])){
			$semaine = $_POST["semaine"];
		}
		else{
			$semaine = '';
		}
		if(isset($_POST["correction_type"])){
			$correction_type = $_POST["correction_type"];
		}
		else{
			$correction_type = '';
		}
        $date = new DateTime();
        if (!empty($semaine)) {
            $week = $semaine;
            $year = $date->format("Y");
        } else {
            $week = $date->format("W");
            $year = $date->format("Y");
        }

		
		$this->db->select('COUNT(`dpr_id`) as dpr_week_count, tbl_dpr_report.week as semi,  tbl_dpr_report.car_supplier as supplier', FALSE);
        $this->db->from('tbl_dpr_report');
        $this->db->where('tbl_dpr_report.week <=', $week);
        $this->db->where('tbl_dpr_report.type_of_request', $correction_type);
		$this->db->where_in('tbl_dpr_report.car_supplier', $supply_name);
        $this->db->group_by('tbl_dpr_report.week');
        $this->db->order_by('tbl_dpr_report.week', 'ASC');
        $query_result = $this->db->get();
        $result = $query_result->result_array();
		
		
//$mesure = $_POST["mesure"];
        $week1 = array();
        foreach ($result as $valHebdo) {
                $week1[$valHebdo['semi']] = $valHebdo['dpr_week_count'];
        }

		//print_r($week1); 
        for ($i = 1; $i <= $week; $i++) {
            if (in_array($i, array_keys($week1))) {
                $resultArray[$i] = $week1[$i];
            } else {
                $resultArray[$i] = 0;
            }
        }       

        $resultca['maxVal'] = abs(floor(max($resultArray)));
        $resultca['minVal'] = floor(min($resultArray));    
        $resultca['td'] = implode(",", $resultArray);
		$resultca['supplier'] = $supply_name;
        return $resultca;
    }
	
	public function car_supplier()
    {
		$this->db->select('tbl_dpr_report.car_supplier', FALSE);
        $this->db->from('tbl_dpr_report');
        $this->db->group_by('tbl_dpr_report.car_supplier');
        $car_supplier = $this->db->get();
        $res = $car_supplier->result_array();
		
		foreach ($res as $row) {
            $car_suppliers[] = $row['car_supplier'];
        }   
		if(isset($_POST["semaine"])){
			$semaine = $_POST["semaine"];
		}
		else{
			$semaine = '';
		}
		if(isset($_POST["correction_type"])){
			$correction_type = $_POST["correction_type"];
		}
		else{
			$correction_type = '';
		}
        $date = new DateTime();
        if (!empty($semaine)) {
            $week = $semaine;
            $year = $date->format("Y");
        } else {
            $week = $date->format("W");
            $year = $date->format("Y");
        }

		
		$this->db->select('COUNT(tbl_dpr_report.dpr_id) as dpr_week_count, tbl_dpr_report.week as semi, tbl_dpr_report.car_supplier as supplier', FALSE);
        $this->db->from('tbl_dpr_report');
        $this->db->where('tbl_dpr_report.week <=', $week);
        $this->db->where('tbl_dpr_report.type_of_request', $correction_type);
        $this->db->where_in('tbl_dpr_report.car_supplier', $car_suppliers);
        $this->db->group_by('tbl_dpr_report.car_supplier,tbl_dpr_report.week');
        $this->db->order_by('dpr_week_count', 'ASC');
        $query_resultant = $this->db->get();
        $resultset = $query_resultant->result_array();


        $week1 = array();
        foreach ($resultset as $valHebdo) {
                $week1[$valHebdo['semi']] = $valHebdo['dpr_week_count'];
        }
        for ($i = 1; $i <= $week; $i++) {
            if (in_array($i, array_keys($week1))) {
                $resultArray[$i] = $week1[$i];
            } else {
                $resultArray[$i] = 0;
            }
        }       

        $resultca['maxVal'] = abs(floor(max($resultArray)));
        $resultca['minVal'] = floor(min($resultArray));    
        return $resultca;
    } 
	
	public function display_supplier()
    {
		$this->db->select('tbl_dpr_report.car_supplier', FALSE);
        $this->db->from('tbl_dpr_report');
        $this->db->group_by('tbl_dpr_report.car_supplier');
        $car_supplier = $this->db->get();
        $res = $car_supplier->result_array();
		
		foreach ($res as $row) {
            $car_suppliers[] = $row['car_supplier'];
        } 

		for ($i = 0; $i <= 3; $i++) {
			$temp[] = $this->display_graph($car_suppliers[$i]);
			foreach ($temp as $row) {
				$resultca['max_'.$i] = $row['maxVal'];
				$resultca['min_'.$i] = $row['minVal'];
				$resultca['tdtot_'.$i] = $row['td'];
				$resultca['supplier_'.$i] = $car_suppliers[$i];
			}
		}
        return $resultca;
    }

	public function display_bar($supply_name)
    {
		$this->db->select('COUNT(`dpr_id`) as dpr_week_count, tbl_dpr_report.correction_field as corrections,  tbl_dpr_report.car_supplier as supplier', FALSE);
        $this->db->from('tbl_dpr_report');
		$this->db->where_in('tbl_dpr_report.car_supplier', $supply_name);
        $this->db->group_by('tbl_dpr_report.correction_field');
        $this->db->order_by('tbl_dpr_report.correction_field', 'ASC');
        $query_result = $this->db->get();
        $result = $query_result->result_array();
		//echo $this->db->last_query();
 
		$corrections_arr1 = array();
        foreach ($result as $valHebdo) {
            $corrections_arr1[$valHebdo['corrections']] = $valHebdo['dpr_week_count'];
			//$correction_current[] = $valHebdo['corrections'];
        }
		 /* echo "<pre>";
		print_r($correction_current);  */
		$temp[] = $this->corrections_list();
		$correction_arr2 = $temp[0]['correction_withoutquotes'];
		
		$corrections_arr2 = explode(",",$correction_arr2);
		//$result1 = array_flip($corrections_arr2);
		/* echo "<pre>";
		print_r($corrections_arr2); */
		
		
		$array_new = [];
		foreach($corrections_arr2 as $key)
		{
			if(array_key_exists($key, $corrections_arr1))
			{
				$array_new[$key] = $corrections_arr1[$key];
			}
			else {
				$array_new[$key] = 0;
			}
			
		}
		
 /*       for ($i = 1; $i <= 4; $i++) {
            if (in_array($i, array_keys($correction_arr))) {
                $resultArray[$i] = $correction_arr[$i];
            } else {
                $resultArray[$i] = 0;
            }
        }  
*/
		
//print_R($corrections_array); exit;

		$resultca['corrections'] = "'" . implode("','", $corrections_arr2) . "'";
        $resultca['td'] = implode(",", $array_new);
		$resultca['supplier'] = $supply_name;
        return $resultca;
    }

	public function display_bar_supplier()
    {
		$this->db->select('tbl_dpr_report.car_supplier', FALSE);
        $this->db->from('tbl_dpr_report');
        $this->db->group_by('tbl_dpr_report.car_supplier');
        $car_supplier = $this->db->get();
        $res = $car_supplier->result_array();
		$count_loop = 0;
		foreach ($res as $row) {
		$count_loop++;
            $car_suppliers[] = $row['car_supplier'];
        } 

		for ($i = 0; $i <= $count_loop-1; $i++) {
			$temp[] = $this->display_bar($car_suppliers[$i]);
			foreach ($temp as $row) {
				$resultca['corrections'] = $row['corrections'];
				$resultca['tdtot_'.$i] = $row['td'];
				$resultca['supplier_'.$i] = $car_suppliers[$i];
			}
		}
        return $resultca;
    }
	
	public function corrections_list()
    {
		$this->db->select('COUNT(`dpr_id`) as dpr_week_count, tbl_dpr_report.correction_field as corrections', FALSE);
        $this->db->from('tbl_dpr_report');
        $this->db->group_by('tbl_dpr_report.correction_field');
		$this->db->order_by('tbl_dpr_report.correction_field', 'ASC');
        $supplier_count = $this->db->get();
        $res = $supplier_count->result_array();
		
		foreach ($res as $row) {
            $corrections_array[] = $row['corrections'];
			$dpr[] = $row['dpr_week_count'];
        }   
		$resultca['corrections'] = "'" . implode("','", $corrections_array) . "'";
		$resultca['correction_withoutquotes'] = implode(",", $corrections_array);
        $resultca['maxVal'] = abs(floor(max($dpr)));
        $resultca['minVal'] = floor(min($dpr));    
        return $resultca;
    }  
	
	public function display_pie()
    {
		if(isset($_POST["correction_type"])){
			$correction_type = $_POST["correction_type"];
		}
		else{
			$correction_type = '';
		}
		$this->db->select('COUNT(`dpr_id`) as dpr_week_count, tbl_dpr_report.car_supplier', FALSE);
        $this->db->from('tbl_dpr_report');
		$this->db->where('tbl_dpr_report.type_of_request', $correction_type);
        $this->db->group_by('tbl_dpr_report.car_supplier');
		$this->db->order_by('tbl_dpr_report.car_supplier', 'ASC');
        $car_supplier = $this->db->get();
        $res = $car_supplier->result_array();
		//echo $this->db->last_query();
		
		$countloop = 0;
		foreach ($res as $row) {
		$countloop++;
            $car_suppliers[] = $row['car_supplier'];
			$dpr[] = $row['dpr_week_count'];
        } 
		
		//print_r($car_suppliers); 
		$resultca['correction'] = $correction_type;
		for ($i = 0; $i <= $countloop-1; $i++) {
			$resultca['car_suppliers_'.$i] = $car_suppliers[$i];
			$resultca['dpr_'.$i] = $dpr[$i]; 
		}
		/* $resultca['corrections'] = "'" . implode("','", $corrections_array) . "'";
		$resultca['correction_withoutquotes'] = implode(",", $corrections_array);
        $resultca['maxVal'] = abs(floor(max($dpr)));
        $resultca['minVal'] = floor(min($dpr));   */  
        return $resultca;
    }
}
 